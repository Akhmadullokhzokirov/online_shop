import 'package:flutter/material.dart';
import 'package:online_shop/models/product.dart';
import 'package:online_shop/providers/products.dart';
import 'package:online_shop/screens/home_screen.dart';
import 'package:online_shop/screens/product_details_screen.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<Products>(
      create: (ctx) {
        return Products();
      },
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
            useMaterial3: false,
            fontFamily: 'EduNSWACTFoundation-SemiBold'),
        debugShowCheckedModeBanner: false,
        home: HomeScreen(),
        routes: {
          ProductDetailsScreen.routeName: (ctx) => const ProductDetailsScreen(),
        },
      ),
    );
  }
}
