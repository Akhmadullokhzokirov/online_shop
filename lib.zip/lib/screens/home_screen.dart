import 'package:flutter/material.dart';
import '../widgets/products_grid.dart';

enum FiltersOption {
  Favorite,
  All,
}

class HomeScreen extends StatefulWidget {
  HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  var _showOnlyFavorite = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('My shop'),
        actions: [
          PopupMenuButton(onSelected: (FiltersOption filter) {
            setState(() {
              if (filter == FiltersOption.All) {
                // .... show all
                _showOnlyFavorite = false;
              } else {
                // ... show Favorite
                _showOnlyFavorite = true;
              }
            });
            print(filter);
          }, itemBuilder: (ctx) {
            return const [
              PopupMenuItem(
                child: Text("All"),
                value: FiltersOption.All,
              ),
              PopupMenuItem(
                child: Text("Favorite"),
                value: FiltersOption.Favorite,
              ),
            ];
          })
        ],
      ),
      body: ProductsGrid(_showOnlyFavorite),
    );
  }
}
