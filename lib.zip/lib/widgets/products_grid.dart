// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:online_shop/providers/products.dart';
import 'package:online_shop/widgets/product_item.dart';

import '../models/product.dart';

class ProductsGrid extends StatelessWidget {
  final bool showFavorite;
  const ProductsGrid(
    this.showFavorite, {
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final productsData = Provider.of<Products>(context);
    final products = showFavorite ? productsData.favorites : productsData.list;
    print(showFavorite);
    return GridView.builder(
        padding: const EdgeInsets.all(20),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 1,
          childAspectRatio: 3 / 2,
          mainAxisSpacing: 20,
          crossAxisSpacing: 20,
        ),
        itemCount: products.length,
        itemBuilder: (ctx, i) {
          return ChangeNotifierProvider(
            create: (ctx) => products[i],
            child: ProductItem(),
          );
        });
  }
}
