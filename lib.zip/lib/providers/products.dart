

import 'package:flutter/material.dart';
import '../models/product.dart';

class Products with ChangeNotifier{
  List<Product> _list = [ Product(
      id: 'p1',
      title: 'Macbook Pro',
      description: "Awesome",
      price: 1200,
      imageUrl:
          "https://media.cnn.com/api/v1/images/stellar/prod/230125131405-macbook-pro-14-inch-2023-review-cnnu-7.jpg?c=original",
    ),
    Product(
      id: 'p2',
      title: 'Airpods',
      description: "Awesome",
      price: 900,
      imageUrl:
          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5znXZbMeKOC9tDjpSfES17VnST18WvoyZsQ&usqp=CAU',
    ),
    Product(
      id: 'p3',
      title: 'Smart watch',
      description: "Awesome",
      price: 1500,
      imageUrl:
          "https://cdn11.bigcommerce.com/s-4q0pjazhsg/images/stencil/1280x1280/products/37946/93267/10__57636.1670330491.jpg?c=3",
    ),];

  List<Product> get list {
    return [..._list];
  }
  List<Product> get favorites {
    return _list.where((product) => product.isFavorite).toList();
  }

  void addProduct() {
 // _list.add(value);
  notifyListeners();
  }
  Product findById(String productId) {
    return _list.firstWhere((product) => product.id == productId);
  }
}